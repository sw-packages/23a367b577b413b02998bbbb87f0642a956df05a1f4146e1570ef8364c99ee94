#define __NO_A_OUT_SUPPORT 1
